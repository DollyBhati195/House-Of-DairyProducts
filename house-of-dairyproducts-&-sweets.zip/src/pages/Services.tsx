import React from 'react';
import { Truck, Users, Gift } from 'lucide-react';

export default function Services() {
  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto">
        
        <div className="text-left mb-16 border-b border-brand-ink/10 pb-8">
          <p className="font-sans text-[10px] tracking-widest uppercase mb-4 opacity-50">Our Capabilities</p>
          <h1 className="text-6xl md:text-8xl text-brand-ink mb-6 font-light leading-[0.9]">
            Our <span className="italic">Services</span>
          </h1>
          <p className="font-sans text-sm opacity-80 max-w-xl text-brand-ink">
            More than just a shop, we provide comprehensive dairy and sweet solutions for your daily needs and special occasions.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pb-12">
          <ServiceCard
            icon={<Truck className="w-6 h-6 text-brand-orange" />}
            title="Home Delivery"
            description="Start your morning right. We offer early morning local delivery of fresh milk across Jodhpur. Setup a monthly subscription so you never run out."
            image="https://plus.unsplash.com/premium_photo-1682090260563-191f8160ca48?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8ZGVsaXZlcnl8ZW58MHx8MHx8fDA%3D"
          />
          <ServiceCard
            icon={<Users className="w-6 h-6 text-brand-orange" />}
            title="Bulk Orders"
            description="Planning a wedding or a corporate event? We handle bulk orders for milk, paneer, and sweets, guaranteeing freshness and timely delivery for your guests."
            image="https://plus.unsplash.com/premium_photo-1682129768936-c5b7c3033cdc?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8YnVsayUyMG9yZGVyc3xlbnwwfHwwfHx8MA%3D%3D"
          />
          <ServiceCard
            icon={<Gift className="w-6 h-6 text-brand-orange" />}
            title="Custom Sweet Boxes"
            description="Celebrate festivals like Diwali or Raksha Bandhan with our beautifully crafted, customized sweet boxes. Perfect for corporate gifting or family giveaways."
            image="https://images.unsplash.com/photo-1605807646983-377bc5a76493?auto=format&fit=crop&q=80"
          />
        </div>

      </div>
    </div>
  );
}

function ServiceCard({ icon, title, description, image }: { icon: React.ReactNode, title: string, description: string, image: string }) {
  return (
    <div className="bg-brand-panel rounded-tr-[80px] overflow-hidden border border-brand-ink/5 flex flex-col group">
      <div className="h-64 overflow-hidden relative border-b border-brand-ink/5">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 mix-blend-multiply opacity-90" 
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-6 left-6 bg-brand-bg w-12 h-12 rounded-full flex items-center justify-center border border-brand-ink/10">
          {icon}
        </div>
      </div>
      <div className="p-8 flex-1 flex flex-col bg-brand-panel">
        <h3 className="text-3xl font-light text-brand-ink mb-4">{title}</h3>
        <p className="text-sm opacity-70 leading-relaxed font-sans flex-1 text-brand-ink">
          {description}
        </p>
        <button className="border-b border-brand-ink/20 mt-8 font-sans text-[10px] tracking-widest text-brand-ink uppercase self-start pb-1 hover:border-brand-ink transition-colors">
          Learn More
        </button>
      </div>
    </div>
  );
}
