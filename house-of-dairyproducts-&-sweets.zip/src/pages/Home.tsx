import React from 'react';
import { NavLink } from 'react-router-dom';
import { MoveRight, Star, Heart, Droplets } from 'lucide-react';
import { motion } from 'motion/react';

export default function Home() {
  return (
    <div className="flex flex-col gap-16 pb-12">
      {/* Hero Section */}
      <section className="relative min-h-[70vh] grid grid-cols-1 lg:grid-cols-12 gap-8 items-center py-4 lg:py-12">
        <div className="order-2 lg:order-2 lg:col-span-6 relative h-[400px] lg:h-[600px] w-full z-0 rounded-t-full lg:rounded-tr-[120px] lg:rounded-tl-none overflow-hidden border border-black/5 bg-brand-panel">
          <img
            src="https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&q=80"
            alt="Fresh Milk Pouring"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-brand-orange/10 mix-blend-multiply" />
        </div>

        <div className="order-1 lg:order-1 lg:col-span-6 relative z-10 w-full flex flex-col pt-4 pr-0 lg:pr-12">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className=""
          >
            <div className="bg-brand-orange text-white p-2 w-fit text-[10px] uppercase tracking-widest mb-6 px-4 font-sans">
              EST. 2026 | Ajmer
            </div>
            <h1 className="text-6xl md:text-7xl lg:text-8xl font-light mb-8 leading-[0.9] text-brand-ink">
              Fresh Milk <br />
              <span className="italic font-normal">& Traditional</span> <br /> Sweets
            </h1>
            <p className="font-sans text-sm leading-relaxed opacity-80 mb-10 text-brand-ink max-w-lg">
              A trusted local dairy in Rajasthan. We are committed to providing high-quality milk and authentic Indian sweets made using traditional recipes direct from the farm.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <NavLink
                to="/products"
                className="px-8 py-3 bg-brand-green text-white font-sans text-xs uppercase tracking-widest transition-colors text-center inline-flex items-center justify-center group"
              >
                Our Products
                <MoveRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </NavLink>
              <NavLink
                to="/contact"
                className="px-8 py-3 border border-black/20 font-sans text-xs uppercase tracking-widest text-center text-brand-ink hover:bg-brand-ink hover:text-brand-bg transition-colors"
              >
                Visit Store
              </NavLink>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Highlights Section */}
      <section className="border-t border-brand-ink/10 pt-16">
        <div className="mb-12">
          <h2 className="text-4xl lg:text-5xl font-light text-brand-ink mb-4">Why Choose Us?</h2>
          <p className="font-sans text-sm opacity-60 max-w-2xl text-brand-ink leading-relaxed">
            We are committed to delivering the highest quality dairy in Ajmer with no compromises on health or taste.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <FeatureCard 
            icon={<Droplets className="w-5 h-5 text-brand-orange" />}
            title="100% Pure Milk"
            description="Fresh cow and buffalo milk directly from our healthy, well-fed cattle."
          />
          <FeatureCard 
            icon={<Heart className="w-5 h-5 text-brand-orange" />}
            title="Homemade Sweets"
            description="Crafted using traditional family recipes and pure ghee for authentic taste."
          />
          <FeatureCard 
            icon={<MoveRight className="w-5 h-5 text-brand-orange" />}
            title="Daily Delivery"
            description="Fast and reliable home delivery every morning straight to your doorstep."
          />
          <FeatureCard 
            icon={<Star className="w-5 h-5 text-brand-orange" />}
            title="No Preservatives"
            description="Natural freshness guaranteed. We don't use any harmful chemicals or preservatives."
          />
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-brand-green text-white rounded-tr-[80px] lg:rounded-tr-[120px] p-8 lg:p-16 w-full relative overflow-hidden">
        <div className="absolute -bottom-10 right-8 w-64 h-64 bg-brand-orange rounded-full mix-blend-multiply opacity-30 blur-3xl"></div>
        <div className="mb-12 relative z-10 flex flex-col md:flex-row justify-between items-start md:items-end">
          <h2 className="text-4xl lg:text-5xl font-light text-white mb-4 md:mb-0">What Our <br/><span className="italic text-white opacity-80">Customers Say</span></h2>
          <p className="text-[10px] uppercase tracking-[0.3em] opacity-60 font-sans">Trusted Locally</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
          <TestimonialCard 
            quote="Best dairy products in Jodhpur!"
            author="Priya Sharma"
          />
          <TestimonialCard 
            quote="Fresh milk and amazing sweets! My family loves the Kaju Katli."
            author="Mohan Singh"
          />
          <TestimonialCard 
            quote="Highly recommended for festivals. Perfect bulk orders."
            author="Anita Verma"
          />
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="bg-brand-panel p-6 rounded-tr-[30px] border border-black/5 hover:border-black/20 transition-colors flex flex-col items-start text-left">
      <div className="mb-8 flex items-center justify-center rounded-full">
        {icon}
      </div>
      <h3 className="text-lg font-sans opacity-80 mb-2 uppercase tracking-widest">{title}</h3>
      <p className="font-serif text-xl leading-relaxed text-brand-ink">{description}</p>
    </div>
  );
}

function TestimonialCard({ quote, author }: { quote: string, author: string }) {
  return (
    <div className="border-t border-white/20 pt-6 flex flex-col justify-between">
      <div>
        <p className="text-xl font-light italic mb-8 text-white leading-relaxed">"{quote}"</p>
      </div>
      <div className="flex flex-col gap-2">
         <div className="flex text-brand-orange mb-2">
           {[...Array(5)].map((_, i) => <Star key={i} className="w-3 h-3 fill-current" />)}
         </div>
         <span className="font-sans text-[10px] uppercase tracking-widest opacity-50">— {author}</span>
      </div>
    </div>
  );
}
