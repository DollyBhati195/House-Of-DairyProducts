import React from 'react';

export default function About() {
  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto">
        
        <div className="text-left mb-16 border-b border-brand-ink/10 pb-8 flex flex-col md:flex-row justify-between items-end">
          <div>
            <p className="font-sans text-brand-orange tracking-widest uppercase mb-4 text-[10px]">
              Est. 2018
            </p>
            <h1 className="text-6xl md:text-8xl font-light text-brand-ink leading-[0.9]">
              Our <span className="italic">Story</span>
            </h1>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          <div className="relative">
            <div className="aspect-[4/5] rounded-tl-[120px] rounded-br-[120px] overflow-hidden bg-brand-panel border border-brand-ink/5">
              <img 
                src="https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80" 
                alt="Dairy Farm" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            {/* Decorative element */}
            <div className="absolute -bottom-6 -left-6 w-48 h-48 bg-brand-orange rounded-full mix-blend-multiply blur-3xl opacity-20 -z-10"></div>
          </div>

          <div className="space-y-8 pt-8">
            <h2 className="text-4xl lg:text-5xl text-brand-ink font-light leading-[1.1]">
              A Legacy of <span className="italic text-brand-orange">Purity</span> and Taste
            </h2>
            
            <div className="space-y-6 text-sm text-brand-ink/80 leading-relaxed font-sans mt-8">
              <p>
                <strong>House of DairyProducts & Sweets</strong> is a trusted local dairy business located near the vibrant Sardarpura Market in Jodhpur, Rajasthan. Established in 2018 by Ramesh Choudhary, our journey began with a simple mission: to bring unadulterated, farm-fresh milk to the local community.
              </p>
              <p>
                We are committed to providing high-quality milk and authentic Indian sweets made using traditional recipes. Our goal is to deliver freshness and purity directly to your home. Every day starts early for us to ensure that the milk reaching your doorstep is as fresh as it gets.
              </p>
              <p>
                Over the years, we expanded our offerings to include premium dairy by-products like pure ghee, and a wide array of homemade traditional sweets, crafted meticulously without any artificial preservatives.  
              </p>
            </div>

            <div className="bg-brand-panel p-8 rounded-tr-[40px] border border-black/5 mt-12 hidden sm:block">
              <div className="grid grid-cols-3 gap-6 text-left">
                <div className="border-r border-brand-ink/10">
                  <h4 className="text-4xl text-brand-ink font-light mb-1">100<span className="text-brand-orange">%</span></h4>
                  <p className="text-[9px] uppercase tracking-widest opacity-60 font-sans">Pure Quality</p>
                </div>
                <div className="border-r border-brand-ink/10 pl-2">
                  <h4 className="text-4xl text-brand-ink font-light mb-1">2K<span className="text-brand-orange">+</span></h4>
                  <p className="text-[9px] uppercase tracking-widest opacity-60 font-sans">Families</p>
                </div>
                <div className="pl-2">
                  <h4 className="text-3xl text-brand-ink font-light mb-1 mt-1">2026</h4>
                  <p className="text-[9px] uppercase tracking-widest opacity-60 font-sans mt-2">Founded</p>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
