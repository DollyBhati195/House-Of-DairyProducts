import React from 'react';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

export default function Contact() {
  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto">
        
        <div className="text-left mb-16 border-b border-brand-ink/10 pb-8">
          <p className="font-sans text-[10px] tracking-widest uppercase mb-4 opacity-50">Reach Out</p>
          <h1 className="text-6xl md:text-8xl text-brand-ink mb-6 font-light leading-[0.9]">
            Let's <span className="italic">Talk</span>
          </h1>
          <p className="font-sans text-sm opacity-80 max-w-xl text-brand-ink">
            Have a bulk order request or need home delivery? Contact us today. We would love to hear from you.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 bg-transparent pb-16">
          
          {/* Contact Details */}
          <div className="p-10 lg:p-14 bg-brand-green text-brand-bg relative overflow-hidden rounded-tr-[120px]">
            <div className="absolute -bottom-16 -right-16 w-64 h-64 bg-brand-orange rounded-full mix-blend-multiply opacity-30 blur-3xl"></div>
            
            <h3 className="text-3xl font-light text-brand-bg mb-12 relative z-10">Contact Information</h3>
            
            <div className="space-y-10 relative z-10">
              <div className="flex items-start">
                <MapPin className="w-5 h-5 text-brand-orange mr-6 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-sans text-[10px] uppercase tracking-[0.2em] opacity-60 mb-2">Store Address</h4>
                  <p className="font-light text-lg">Near Narayni Bhawan ,<br />Ajmer, Rajasthan, India</p>
                </div>
              </div>

              <div className="flex items-start">
                <Phone className="w-5 h-5 text-brand-orange mr-6 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-sans text-[10px] uppercase tracking-[0.2em] opacity-60 mb-2">Phone</h4>
                  <p className="font-light text-lg">+91 7742117822</p>
                </div>
              </div>

              <div className="flex items-start">
                <Mail className="w-5 h-5 text-brand-orange mr-6 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-sans text-[10px] uppercase tracking-[0.2em] opacity-60 mb-2">Email</h4>
                  <p className="font-light text-lg">houseofdairyproducts@gmail.com</p>
                </div>
              </div>

              <div className="flex items-start">
                <Clock className="w-5 h-5 text-brand-orange mr-6 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-sans text-[10px] uppercase tracking-[0.2em] opacity-60 mb-2">Working Hours</h4>
                  <p className="font-light text-lg">Monday - Sunday: 6:00 AM – 10:00 PM</p>
                </div>
              </div>
            </div>
          </div>

          {/* Map/Form Section */}
          <div className="flex flex-col justify-start">
            <h3 className="text-3xl font-light text-brand-ink mb-8">Send an Inquiry</h3>
             
            <form className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="flex flex-col border-b border-brand-ink/20">
                   <label className="font-sans text-[9px] uppercase tracking-widest opacity-50 mb-2">Your Name</label>
                   <input type="text" className="w-full py-2 bg-transparent focus:outline-none text-brand-ink font-serif text-lg" />
                </div>
                <div className="flex flex-col border-b border-brand-ink/20">
                   <label className="font-sans text-[9px] uppercase tracking-widest opacity-50 mb-2">Phone Number</label>
                   <input type="tel" className="w-full py-2 bg-transparent focus:outline-none text-brand-ink font-serif text-lg" />
                </div>
              </div>
              <div className="flex flex-col border-b border-brand-ink/20">
                 <label className="font-sans text-[9px] uppercase tracking-widest opacity-50 mb-2">Your Message</label>
                 <textarea rows={3} className="w-full py-2 bg-transparent focus:outline-none text-brand-ink font-serif text-lg resize-none"></textarea>
              </div>
              <button type="button" className="bg-brand-ink text-brand-bg font-sans text-[10px] uppercase tracking-[0.2em] py-4 px-10 transition-colors hover:bg-brand-green w-full sm:w-auto">
                Submit Request
              </button>
            </form>

            <div className="w-full h-48 md:h-64 mt-12 bg-brand-panel border border-brand-ink/10 mix-blend-multiply opacity-80 overflow-hidden">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d114459.79159981512!2d72.93510526978586!3d26.27049811352497!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39418c4eaa06fcb9%3A0x8114ea5b0eea1f81!2sSardarpura%2C%20Jodhpur%2C%20Rajasthan!5e0!3m2!1sen!2sin!4v1713890251703!5m2!1sen!2sin" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen={false} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Google Maps Location"
                className="grayscale"
              ></iframe>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
