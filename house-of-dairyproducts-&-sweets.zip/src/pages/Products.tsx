import React from 'react';
import { ShoppingCart } from 'lucide-react';

const DUMMY_PRODUCTS = [
  { id: 1, name: 'Fresh Cow Milk', price: 60, unit: 'L', category: 'Dairy', img: 'https://images.unsplash.com/photo-1559598467-f8b76c8155d0?auto=format&fit=crop&q=80' },
  { id: 2, name: 'Buffalo Milk', price: 70, unit: 'L', category: 'Dairy', img: 'https://images.unsplash.com/photo-1563636619-e9143da7973b?auto=format&fit=crop&q=80' },
  { id: 3, name: 'Fresh Paneer', price: 320, unit: 'kg', category: 'Dairy', img: 'https://plus.unsplash.com/premium_photo-1695044277238-6eac8969fb77?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8ZnJlc2glMjBwYW5lZXJ8ZW58MHx8MHx8fDA%3D' },
  { id: 4, name: 'Pure Ghee', price: 600, unit: 'kg', category: 'Dairy', img: 'https://images.unsplash.com/photo-1573812461383-e5f8b759d12e?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8cHVyZSUyMGdoZWV8ZW58MHx8MHx8fDA%3D' }, // Using somewhat similar imagery
  { id: 5, name: 'Ras Malai', price: 400, unit: 'kg', category: 'Sweets', img: 'https://media.istockphoto.com/id/2229698116/photo/delicious-rasmalai-served-in-a-bowl-placed-beside-a-decorative-rakhi-and-a-traditional-roli.webp?a=1&b=1&s=612x612&w=0&k=20&c=MLnptNWlkJKlMXYxj8kMgMeoX4-VXP-P4EH2s3FTnJs=' }, 
  { id: 6, name: 'Rasgulla', price: 380, unit: 'kg', category: 'Sweets', img: 'https://media.istockphoto.com/id/1127496067/photo/bowl-full-with-rasgulla-and-pistachios-a-food-table-top-pune-india.webp?a=1&b=1&s=612x612&w=0&k=20&c=zhjOqF72JuzZ_2tiJFJTaLgBQizGvRGIGxPkgLcLGV0=' },
  { id: 7, name: 'Kaju Katli', price: 800, unit: 'kg', category: 'Sweets', img: 'https://images.unsplash.com/photo-1699708263762-00ca477760bd?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8a2FqdSUyMGthdGxpfGVufDB8fDB8fHww' },
  { id: 8, name: 'Besan Ladoo', price: 450, unit: 'kg', category: 'Sweets', img: 'https://media.istockphoto.com/id/982302046/photo/rava-ladoo-or-semolina-laddu-with-cashew-nut-topping-popular-festival-food-from-india-served.webp?a=1&b=1&s=612x612&w=0&k=20&c=mKcLpiJdc2fY3siQJ5O-_htDQCjyqhy2JGADcDdd8Ys=' },
  { id: 9, name: 'Milk Cake', price: 550, unit: 'kg', category: 'Sweets', img: 'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8TWlsayUyMGNha2V8ZW58MHx8MHx8fDA%3D' },
  { id: 10, name: 'Butter', price: 500, unit: 'kg', category: 'Dairy', img: 'https://images.unsplash.com/photo-1589985269102-ff38adf6f00d?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8YnV0dGVyfGVufDB8fDB8fHww' },
  { id: 11, name: 'Cheese', price: 350, unit: 'kg', category: 'Dairy', img: 'https://images.unsplash.com/photo-1627935722051-395636b0d8a5?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8Y2hlZXNlfGVufDB8fDB8fHww' },
  { id: 12, name: 'Gulab Jamun', price: 200, unit: 'kg', category: 'Sweets', img: 'https://media.istockphoto.com/id/494962034/photo/diwali-sweets.webp?a=1&b=1&s=612x612&w=0&k=20&c=qG1wcUyHU5H0ZQYWAn_cVIi2ttWtVnqMNmRqH4xs-9I=' },
];

export default function Products() {
  const dairyProducts = DUMMY_PRODUCTS.filter(p => p.category === 'Dairy');
  const sweets = DUMMY_PRODUCTS.filter(p => p.category === 'Sweets');

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto flex flex-col gap-16">
        
        <div className="text-left border-b border-brand-ink/10 pb-8 relative">
          <p className="font-sans text-[10px] tracking-widest uppercase mb-4 opacity-50">Our Offerings</p>
          <h1 className="text-6xl md:text-8xl font-light text-brand-ink leading-[0.9]">
            Dairy <span className="italic">& Sweets</span>
          </h1>
          <p className="mt-8 font-sans text-sm opacity-80 max-w-xl text-brand-ink">
            Authentic, hygienic, and prepared fresh every day manually with pure love.
          </p>
        </div>

        {/* Dairy Section */}
        <div>
          <h2 className="text-[11px] font-sans uppercase tracking-[0.3em] opacity-50 mb-8 pb-4 border-b border-brand-ink/5">Dairy Products</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {dairyProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>

        {/* Sweets Section */}
        <div className="pb-12">
          <h2 className="text-[11px] font-sans uppercase tracking-[0.3em] opacity-50 mb-8 pb-4 border-b border-brand-ink/5 pt-8">Traditional Sweets</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {sweets.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}

function ProductCard({ product }: { product: any }) {
  return (
    <div className="bg-brand-panel rounded-tr-[40px] overflow-hidden border border-brand-ink/5 flex flex-col group h-full">
      <div className="aspect-[4/3] overflow-hidden bg-brand-ink/5 relative">
        <img 
          src={product.img} 
          alt={product.name} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-4 left-4 bg-brand-bg px-3 py-1 text-[9px] uppercase tracking-widest opacity-90 border border-brand-ink/10">
          {product.category}
        </div>
      </div>
      <div className="p-6 flex-1 flex flex-col justify-between">
        <h3 className="font-light text-2xl text-brand-ink leading-tight mb-4">{product.name}</h3>
        <div className="flex justify-between items-end border-t border-brand-ink/10 pt-4 mt-auto">
          <div>
             <span className="text-xl font-sans text-brand-ink">₹{product.price}</span>
             <span className="text-[10px] font-sans uppercase opacity-50 ml-1">/{product.unit}</span>
          </div>
          <button className="text-brand-ink hover:text-brand-orange transition-colors focus:outline-none">
            <ShoppingCart className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
