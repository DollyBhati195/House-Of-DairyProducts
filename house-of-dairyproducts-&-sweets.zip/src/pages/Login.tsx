import React, { useState } from 'react';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if ((username === 'admin' && password === 'admin123') || (username === 'user1' && password === 'user123')) {
      alert(`Welcome, ${username}! Login successful.`);
      setError('');
    } else {
      setError('Invalid username or password. Try admin/admin123');
    }
  };

  return (
    <div className="min-h-[80vh] flex flex-col justify-center items-center px-4 relative py-12">
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-brand-orange rounded-full mix-blend-multiply opacity-5 blur-[120px] pointer-events-none"></div>

      <div className="max-w-md w-full bg-brand-panel border border-brand-ink/10 p-12 rounded-tr-[80px] shadow-sm relative z-10">
        
        <div className="text-left mb-12">
          <h1 className="text-4xl font-light text-brand-ink mb-2 leading-none">Welcome Back</h1>
          <p className="text-brand-ink opacity-50 font-sans text-[10px] uppercase tracking-[0.2em] mt-4">Login to your account</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-8 flex flex-col">
          {error && (
            <div className="bg-red-50/50 text-red-800 text-xs p-4 border border-red-800/10 text-center font-sans tracking-wide">
              {error}
            </div>
          )}
          
          <div className="flex flex-col border-b border-brand-ink/20 focus-within:border-brand-ink/60 transition-colors">
            <label className="font-sans text-[9px] uppercase tracking-widest opacity-50 mb-2 text-brand-ink">
              Username
            </label>
            <input 
              type="text" 
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full py-2 bg-transparent focus:outline-none text-brand-ink font-serif text-lg"
              placeholder="admin"
              required
            />
          </div>

          <div className="flex flex-col border-b border-brand-ink/20 focus-within:border-brand-ink/60 transition-colors relative">
            <label className="font-sans text-[9px] uppercase tracking-widest opacity-50 mb-2 text-brand-ink">
              Password
            </label>
            <input 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full py-2 bg-transparent focus:outline-none text-brand-ink font-sans text-xl tracking-[0.3em]"
              placeholder="••••••••"
              required
            />
          </div>

          <div className="flex items-center justify-between text-xs font-sans">
            <label className="flex items-center text-brand-ink opacity-70 cursor-pointer hover:opacity-100">
              <input type="checkbox" className="mr-2 rounded border-brand-ink/20 text-brand-ink focus:ring-brand-ink bg-transparent" />
              Remember me
            </label>
            <a href="#" className="text-brand-ink opacity-70 hover:opacity-100 transition-opacity underline underline-offset-4">
              Forgot password?
            </a>
          </div>

          <button 
            type="submit" 
            className="w-full bg-brand-ink text-brand-bg font-sans text-[10px] uppercase tracking-[0.2em] py-4 transition-colors hover:bg-brand-green mt-4"
          >
            Sign In
          </button>
        </form>

        <div className="mt-12 text-center">
          <p className="text-xs font-sans text-brand-ink opacity-70">
            Don't have an account?{' '}
            <a href="#" className="font-semibold text-brand-ink hover:text-brand-orange transition-colors">
              Register now
            </a>
          </p>
        </div>

        {/* Demo Data Notice */}
        <div className="mt-8 pt-6 border-t border-brand-ink/10 text-[9px] font-sans text-brand-ink opacity-40 text-center uppercase tracking-widest leading-loose">
          <p>Demo: admin / admin123</p>
          <p>Demo: user1 / user123</p>
        </div>
      </div>
    </div>
  );
}
