import React from 'react';

const BLOG_POSTS = [
  {
    id: 1,
    title: "The Incredible Benefits of Drinking Fresh Milk Daily",
    excerpt: "Learn why raw, unadulterated farm milk is far superior to heavily processed alternatives.",
    date: "Oct 12, 2024",
    category: "Health",
    image: "https://images.unsplash.com/photo-1563636619-e9143da7973b?auto=format&fit=crop&q=80"
  },
  {
    id: 2,
    title: "How Traditional Sweets Are Made: Our Process",
    excerpt: "Take a peek into our kitchen where we craft Kaju Katli and Gulab Jamun using age-old recipes.",
    date: "Sep 28, 2025",
    category: "Process",
    image: "https://images.unsplash.com/photo-1661777997130-7eb7b3573963?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTF8fHN3ZWV0cyUyMGFuZCUyMGRhaXJ5JTIwcHJvZHVjdCUyMHNob3B8ZW58MHx8MHx8fDA%3D"
  },
  {
    id: 3,
    title: "Festive Sweet Trends in India: What's Popular This Diwali",
    excerpt: "Discover the top sweet choices families are making this festive season.",
    date: "Jan 05, 2026",
    category: "Culture",
    image: "https://media.istockphoto.com/id/1339043021/photo/diwali-sweets-gujiya-peda-barfi-motichoor-laddu-indian-sweet-dessert-mithai-festival-dish.webp?a=1&b=1&s=612x612&w=0&k=20&c=fEZXii_UXMGm5g0nbN5fYYhjxylweFWus-cjQSWdPgo="
  },
];

export default function Blog() {
  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto">
        
        <div className="text-left mb-16 border-b border-brand-ink/10 pb-8">
          <p className="font-sans text-[10px] tracking-widest uppercase mb-4 opacity-50">Journal</p>
          <h1 className="text-6xl md:text-8xl text-brand-ink mb-6 font-light leading-[0.9]">
            Dairy <span className="italic">& Culture</span>
          </h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-12">
          {BLOG_POSTS.map((post) => (
            <article key={post.id} className="group relative border border-brand-ink/10 rounded-tr-[60px] overflow-hidden bg-brand-panel cursor-pointer h-full flex flex-col">
              <div className="aspect-[4/3] overflow-hidden border-b border-brand-ink/10 relative">
                <img 
                  src={post.image} 
                  alt={post.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 left-4 bg-brand-bg px-3 py-1 font-sans text-[9px] uppercase tracking-widest opacity-90 border border-brand-ink/10">
                  {post.category}
                </div>
              </div>
              <div className="p-8 flex-1 flex flex-col">
                <div className="flex items-center justify-between mb-4 mt-auto">
                  <span className="font-sans text-[9px] uppercase tracking-widest opacity-50">{post.date}</span>
                </div>
                <h3 className="text-2xl font-light text-brand-ink mb-4 group-hover:text-brand-orange transition-colors leading-[1.2]">
                  {post.title}
                </h3>
                <p className="font-sans text-xs opacity-70 leading-relaxed mb-6">
                  {post.excerpt}
                </p>
                <div className="mt-auto">
                  <span className="font-sans text-[9px] uppercase tracking-[0.2em] border-b border-brand-ink/20 pb-1">Read Article</span>
                </div>
              </div>
            </article>
          ))}
        </div>

      </div>
    </div>
  );
}
