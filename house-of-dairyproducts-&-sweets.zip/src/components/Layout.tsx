import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import Footer from './Footer';

export default function Layout() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Products', path: '/products' },
    { name: 'Services', path: '/services' },
    { name: 'About', path: '/about' },
    { name: 'Blog', path: '/blog' },
    { name: 'Contact', path: '/contact' }
  ];

  return (
    <div className="min-h-screen flex flex-col font-serif bg-brand-bg text-brand-ink overflow-x-hidden">
      {/* Navigation */}
      <nav className="mb-8 pt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <header className="flex justify-between items-center border-b border-brand-ink/10 pb-6 relative z-50">
            {/* Logo */}
            <div className="flex flex-col">
              <span className="text-2xl font-black tracking-tighter uppercase italic">House of Dairy</span>
              <span className="text-[10px] uppercase tracking-[0.4em] opacity-60">Pure Taste, Fresh Every Day</span>
            </div>

            {/* Desktop Nav */}
            <div className="hidden md:flex gap-8 text-xs uppercase tracking-widest font-sans">
              {navLinks.map((link) => (
                <NavLink
                  key={link.path}
                  to={link.path}
                  className={({ isActive }) =>
                    `transition-colors ${
                      isActive
                        ? 'font-bold border-b border-brand-ink'
                        : 'opacity-50 hover:opacity-100'
                    }`
                  }
                >
                  {link.name}
                </NavLink>
              ))}
              <NavLink
                 to="/login"
                 className="opacity-50 hover:opacity-100"
               >
                 LOGIN
               </NavLink>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden flex items-center">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="opacity-50 hover:opacity-100 focus:outline-none"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </header>
        </div>

        {/* Mobile Nav */}
        {isMenuOpen && (
          <div className="md:hidden bg-brand-bg border-b border-brand-ink/10 absolute w-full left-0 z-50">
            <div className="px-4 pt-2 pb-6 space-y-4 flex flex-col font-sans uppercase text-xs tracking-widest">
              {navLinks.map((link) => (
                <NavLink
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={({ isActive }) =>
                    `${isActive ? 'font-bold' : 'opacity-50'} py-2`
                  }
                >
                  {link.name}
                </NavLink>
              ))}
               <NavLink
                  to="/login"
                  onClick={() => setIsMenuOpen(false)}
                  className="opacity-50 hover:opacity-100 py-2 border-t border-brand-ink/10 mt-2"
                >
                  LOGIN
                </NavLink>
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative">
        {/* Floating shape behind all content */}
        <div className="fixed top-[20%] right-[-10%] w-96 h-96 bg-brand-orange rounded-full mix-blend-multiply opacity-[0.03] blur-[100px] pointer-events-none -z-10"></div>
        <Outlet />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
