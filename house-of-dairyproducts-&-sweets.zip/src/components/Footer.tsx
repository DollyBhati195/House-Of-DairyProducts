import React from 'react';
import { Instagram, Facebook } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="mt-12 pt-6 border-t border-brand-ink/10 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Brand Info */}
          <div className="col-span-1 md:col-span-1">
            <h2 className="text-2xl font-black tracking-tighter uppercase italic text-brand-ink mb-1">House of Dairy</h2>
            <p className="mb-6 text-[10px] uppercase tracking-[0.4em] opacity-60 text-brand-ink">
              Pure Taste, Fresh Every Day
            </p>
            <div className="flex space-x-4">
              <a href="#" className="opacity-50 hover:opacity-100 transition-colors text-brand-ink">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="opacity-50 hover:opacity-100 transition-colors text-brand-ink">
                <Instagram className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="flex flex-col">
             <span className="text-[9px] uppercase tracking-widest opacity-50 mb-3 text-brand-ink">Quick Links</span>
             <ul className="space-y-2 text-xs uppercase tracking-widest">
              <li><a href="/" className="opacity-50 hover:opacity-100 transition-colors text-brand-ink">Home</a></li>
              <li><a href="/about" className="opacity-50 hover:opacity-100 transition-colors text-brand-ink">About Us</a></li>
              <li><a href="/products" className="opacity-50 hover:opacity-100 transition-colors text-brand-ink">Products</a></li>
              <li><a href="/services" className="opacity-50 hover:opacity-100 transition-colors text-brand-ink">Services</a></li>
              <li><a href="/blog" className="opacity-50 hover:opacity-100 transition-colors text-brand-ink">Blog</a></li>
            </ul>
          </div>

          {/* Working Hours */}
          <div className="flex flex-col md:border-l md:border-brand-ink/10 md:pl-6">
            <span className="text-[9px] uppercase tracking-widest opacity-50 mb-3 text-brand-ink">Working Hours</span>
            <ul className="space-y-2 text-xs">
              <li className="flex justify-between max-w-[200px]">
                <span>Mon – Sun</span>
                <span>6:00 AM – 10:00 PM</span>
              </li>
              <li className="flex justify-between max-w-[200px] mt-4">
                <span>Festivals</span>
                <span className="italic">Extended Hours</span>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div className="flex flex-col md:items-end">
            <span className="text-[11px] font-serif italic mb-1 uppercase tracking-wider underline underline-offset-4 text-brand-ink mt-6 md:mt-0">Location & Contact</span>
            <ul className="space-y-2 text-[10px] md:text-right mt-4 opacity-80 uppercase tracking-widest">
              <li>,<br/>Near Narayni Bhawan, Ajmer, Rajasthan</li>
              <li className="pt-2">+91 98765 43210</li>
              <li>houseofdairyproducts@gmail.com</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-brand-ink/10 mt-12 pt-6 flex flex-col sm:flex-row justify-between items-center text-[9px] uppercase tracking-widest text-brand-ink opacity-40 gap-4">
           <p>© {new Date().getFullYear()} House of Dairy. Fresh daily.</p>
           <p>est 2026 | Ajmer</p>
        </div>
      </div>
    </footer>
  );
}
